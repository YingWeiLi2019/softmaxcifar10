from cs231n.classifiers.k_nearest_neighbor import *
from cs231n.classifiers.linear_classifier import *
